#include "Wildboar.h"
#include <stdio.h>


Wildboar::Wildboar()
{
	printf("Wildboar ����\n");
}


Wildboar::~Wildboar()
{
	printf("Wildboar �Ҹ�\n");
}

void Wildboar::Move()
{
	printf("Wildboar �̵��Ѵ�.\n");

}
