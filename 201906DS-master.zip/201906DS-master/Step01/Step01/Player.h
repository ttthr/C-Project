#pragma once
#include "Character.h"

class Player : public Character
{
public:
	Player();
	~Player();

	char name[20];

	void Move();
};

