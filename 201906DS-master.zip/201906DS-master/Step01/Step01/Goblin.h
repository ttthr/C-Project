#pragma once
#include "Monster.h"

class Goblin : public Monster
{
public:
	Goblin();
	~Goblin();

	void Move();
};

