#include "Monster.h"



Monster::Monster()
{
}


Monster::~Monster()
{
}
