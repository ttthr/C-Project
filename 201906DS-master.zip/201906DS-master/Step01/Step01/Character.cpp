#include "Character.h"
#include <stdio.h>


Character::Character()
{
}


Character::~Character()
{
}

void Character::Move()
{
	printf("�̵��Ѵ�.\n");
}
