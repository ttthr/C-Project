#pragma once
class Character
{
public:
	Character();
	~Character();

	int Attack;
	int HP;
	int Speed;

	void Move();
};

