#pragma once
#include "Monster.h"

class Wildboar : public Monster
{
public:
	Wildboar();
	~Wildboar();

	void Move();
};

